from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from pathlib import Path
import json
import webbrowser
import threading

app = Flask(__name__)
CORS(app)

DATA_DIR = Path("sb_json")


# -----------------------------------
# Load One Chapter
# -----------------------------------

def load_chapter(canto, chapter):

    file_path = DATA_DIR / f"canto{canto}" / f"chapter{chapter}.json"

    if not file_path.exists():
        return None

    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


# -----------------------------------
# Auto Open Browser
# -----------------------------------

def open_browser():

    webbrowser.open(
        "http://localhost:5000/reader"
    )


# -----------------------------------
# Load All Verses
# -----------------------------------

def load_all_verses():

    verses = []

    for canto_folder in sorted(DATA_DIR.glob("canto*")):

        for chapter_file in sorted(canto_folder.glob("chapter*.json")):

            try:

                with open(chapter_file, "r", encoding="utf-8") as f:

                    data = json.load(f)

                    if isinstance(data, list):
                        verses.extend(data)

            except Exception as e:
                print(f"Error loading {chapter_file}: {e}")

    return verses


# -----------------------------------
# Routes
# -----------------------------------

@app.route("/")
def home():

    return jsonify({
        "message": "Srimad Bhagavatam API Running"
    })


@app.route("/reader")
def reader():

    return send_from_directory(
        ".",
        "bhagavatam_reader.html"
    )


@app.route("/api/cantos")
def get_cantos():

    result = []

    for canto_folder in sorted(DATA_DIR.glob("canto*")):

        canto_number = int(
            canto_folder.name.replace("canto", "")
        )

        chapters = []

        for chapter_file in sorted(canto_folder.glob("chapter*.json")):

            chapter_number = int(
                chapter_file.stem.replace("chapter", "")
            )

            chapters.append(chapter_number)

        result.append({
            "canto": canto_number,
            "chapters": chapters
        })

    return jsonify(result)


@app.route("/api/chapter/<int:canto>/<int:chapter>")
def get_chapter(canto, chapter):

    data = load_chapter(canto, chapter)

    if data is None:

        return jsonify({
            "error": "Chapter not found"
        }), 404

    return jsonify(data)


@app.route("/api/verse/<verse_id>")
def get_verse(verse_id):

    verses = load_all_verses()

    for verse in verses:

        if verse.get("id") == verse_id:
            return jsonify(verse)

    return jsonify({
        "error": "Verse not found"
    }), 404


@app.route("/api/search")
def search():

    query = request.args.get(
        "q",
        ""
    ).lower().strip()

    if not query:
        return jsonify([])

    verses = load_all_verses()

    results = []

    for verse in verses:

        searchable_text = " ".join([
            str(verse.get("sanskrit", "")),
            str(verse.get("translation", "")),
            str(verse.get("purport", "")),
            str(verse.get("synonyms", ""))
        ]).lower()

        if query in searchable_text:

            results.append({
                "id": verse.get("id"),
                "canto": verse.get("canto"),
                "chapter": verse.get("chapter"),
                "verse": verse.get("verse"),
                "translation": verse.get(
                    "translation",
                    ""
                )[:250]
            })

    return jsonify(results[:100])


# -----------------------------------
# Run Server
# -----------------------------------

if __name__ == "__main__":

    threading.Timer(
        1.5,
        open_browser
    ).start()

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True,
        use_reloader=False
    )
